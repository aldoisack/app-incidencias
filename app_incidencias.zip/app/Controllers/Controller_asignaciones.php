<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Model_asignaciones;
class Controller_asignaciones extends Controller{

}